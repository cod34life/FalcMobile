

package com.example.falcmobile;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;


public class Schedules extends AppCompatActivity implements AdapterView.OnItemClickListener {
    private ListView listview;
    private String url;
    private WebView webView;
    private ArrayAdapter<String> adapt = null;
    public final static String MESSAGE_KEY ="com.example.falcmobile.message_key";

    String[] scheduleItems = new String[]{
            "Academic Years",
            "Dining Services",
            "CIS Sandbox",
            "Fitness Center",
            "Student Center"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.schedule_one);
        listview = (ListView) findViewById(R.id.list);
        listview.setOnItemClickListener(this);
        adapt = new ArrayAdapter<String>(this, R.layout.item, scheduleItems);
        listview.setAdapter(adapt);
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem button) {
        Uri uri;
        switch (button.getItemId()) {
            case R.id.BPD:
                Uri uri3 = Uri.parse("tel:6175551212");
                Intent i3 = new Intent(Intent.ACTION_CALL,uri3);
                startActivity(i3);
            case R.id.Facilities:
                Uri uri2 = Uri.parse("tel:6175550133");
                Intent i2 = new Intent(Intent.ACTION_CALL,uri2);
                startActivity(i2);
            case R.id.RA:
                Uri uri1 = Uri.parse("tel:6175550173");
                Intent i1 = new Intent(Intent.ACTION_CALL,uri1);
                startActivity(i1);
                default:
                return super.onOptionsItemSelected(button);
        }
    }
    public void onItemClick(AdapterView<?> parent, View v, int position, long id) {

        switch (position) {
            case 0:
                url = "https://www.bentley.edu/offices/registrar/academic-calendars";
                Intent intent= new Intent(this ,WebLookUp.class);
                intent.putExtra(MESSAGE_KEY,url);
                startActivity(intent);
                break;
            case 1:
                url = "https://bentley.sodexomyway.com/dining-near-me/hours";
                Intent intent2= new Intent(this ,WebLookUp.class);
                intent2.putExtra(MESSAGE_KEY,url);
                startActivity(intent2);
                break;
            case 2:
                url = "https://cis.bentley.edu/sandbox/";
                Intent intent3= new Intent(this ,WebLookUp.class);
                intent3.putExtra(MESSAGE_KEY,url);
                startActivity(intent3);
                break;
            case 3:
                url = "https://www.bentleyfalcons.com/facilities/hours";
                Intent intent4= new Intent(this ,WebLookUp.class);
                intent4.putExtra(MESSAGE_KEY,url);
                startActivity(intent4);
                break;
            case 4:
                url = "https://www.bentley.edu/university-life/campus-life/student-center";
                Intent intent5= new Intent(this ,WebLookUp.class);
                intent5.putExtra(MESSAGE_KEY,url);
                startActivity(intent5);
                break;
        }
    }

}
