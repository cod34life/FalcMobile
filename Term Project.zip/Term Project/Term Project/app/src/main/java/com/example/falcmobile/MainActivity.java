package com.example.falcmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View.OnClickListener;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextClock;
import android.widget.TextView;
import android.view.View;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends AppCompatActivity implements OnClickListener, TextToSpeech.OnInitListener {

    private TextView home;
    private ImageButton cbtn;
    private ImageButton sbtn;
    private TextView covid;
    private TextView schedules;
    private ImageButton nbtn;
    private ImageButton mbtn;
    private TextView news;
    private TextView misc;
    private TextToSpeech voice;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //locate all UI elements
        home = (TextView) findViewById(R.id.home);
        cbtn = (ImageButton) findViewById(R.id.cbtn);
        sbtn = (ImageButton) findViewById(R.id.sbtn);
        covid = (TextView) findViewById(R.id.covid);
        schedules = (TextView) findViewById(R.id.schedules);
        nbtn = (ImageButton) findViewById(R.id.nbtn);
        mbtn = (ImageButton) findViewById(R.id.mbtn);
        news = (TextView) findViewById(R.id.news);
        misc = (TextView) findViewById(R.id.misc);

        //set all listeners
        cbtn.setOnClickListener(this);
        sbtn.setOnClickListener(this);
        nbtn.setOnClickListener(this);
        mbtn.setOnClickListener(this);
        voice = new TextToSpeech(this, this);
    }

    //when button is clicked, user will know which button they chose because image will enlarge and option will be said out loud
    //user is then taken to the correct page
    @Override
    public void onClick (View v) {
        switch(v.getId()) {
            case R.id.cbtn:

                AnimatorSet bigcovid = new AnimatorSet();
                //animate in these directions
                ObjectAnimator vcovid = ObjectAnimator.ofFloat(cbtn, "scaleY", 1f, 1.5f);
                ObjectAnimator hcovid = ObjectAnimator.ofFloat(cbtn, "scaleX", 1f, 1.5f);
                //start animation
                bigcovid.playTogether(hcovid, vcovid);
                bigcovid.start();

                //getting the text and having program read it
                String optcovid = covid.getText().toString();
                speak("You have chosen the option " + optcovid);

                //opening the page corresponding to the button pressed
                startActivity(new Intent(MainActivity.this, COVID.class));

            case R.id.sbtn:

                AnimatorSet bigschedule = new AnimatorSet();
                ObjectAnimator vschedule= ObjectAnimator.ofFloat(cbtn, "scaleY", 1f, 1.5f);
                ObjectAnimator hschedule = ObjectAnimator.ofFloat(cbtn, "scaleX", 1f, 1.5f);
                //start animation
                bigschedule.playTogether(hschedule, vschedule);
                bigschedule.start();

                String optschedules = schedules.getText().toString();
                speak("You have chosen the option " + optschedules);
                startActivity(new Intent(MainActivity.this, Schedules.class));

            case R.id.nbtn:

                AnimatorSet bignews = new AnimatorSet();
                ObjectAnimator vnews= ObjectAnimator.ofFloat(cbtn, "scaleY", 1f, 1.5f);
                ObjectAnimator hnews = ObjectAnimator.ofFloat(cbtn, "scaleX", 1f, 1.5f);
                //start animation
                bignews.playTogether(hnews, vnews);
                bignews.start();

                String optnews= news.getText().toString();
                speak("You have chosen the option " + optnews);
                startActivity(new Intent(MainActivity.this, News.class));

            case R.id.mbtn:

                AnimatorSet bigmisc= new AnimatorSet();
                ObjectAnimator vmisc= ObjectAnimator.ofFloat(cbtn, "scaleY", 1f, 1.5f);
                ObjectAnimator hmisc = ObjectAnimator.ofFloat(cbtn, "scaleX", 1f, 1.5f);
                //start animation
                bigmisc.playTogether(hmisc, vmisc);
                bigmisc.start();

                String optmisc = misc.getText().toString();
                speak("You have chosen the option miscellaneous");
                startActivity(new Intent(MainActivity.this, Misc.class));
        }
    }

    //set up TextToSpeech method
    public void speak (String output) {
        voice.speak(output, TextToSpeech.QUEUE_FLUSH, null, "Id 0");
    }

    //conditions for if voice works or not
    @Override
    public void onInit (int status){
        //if TextToSpeech enabled
        if (status == TextToSpeech.SUCCESS) {
            int result = voice.setLanguage(Locale.US);

            //if there's issues with the language chosen
            if (result == TextToSpeech.LANG_MISSING_DATA ||
                    result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Toast.makeText(this, "This language is not available or complete", Toast.LENGTH_LONG).show();
            }
        } else
            Toast.makeText(this, "An issue came up, so the device will remain silent for now", Toast.LENGTH_LONG).show();
    }

}
