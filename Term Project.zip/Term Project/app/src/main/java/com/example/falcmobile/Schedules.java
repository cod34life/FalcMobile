package com.example.falcmobile;
/*
 * Use a WebView widget to display a web page.
 * Enter URL, click button or press Enter key.
 *
 * If you click a link in WebView page, the link is opened in the default
 * browser. Similarly, if WebView gets a redirect (HTTP/1.1 301) from the web server
 * the default browser is used to open the web page. To prevent this
 * behavior and open the new web page in WebView, you need to intercept
 * URL loading and open in WebView.
 *
 * This example uses the back key to navigate back to the previous web page.
 */

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

public class Schedules extends Activity {
    private String urlText;
   // private Button searchButton;
    private WebView webView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        // ...
        super.onCreate(savedInstanceState);
        setContentView(R.layout.schedule_one);

        // Get a handle to all user interface elements (find widgets)
        webView = (WebView) findViewById(R.id.web_widget);
        webView.getSettings().setJavaScriptEnabled(true);

        //intercept default URL loading and load in URL from widget that we want
        webView.setWebViewClient(new WebViewClient(){
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url){  // override instead of what?
                view.loadUrl(url);
                return true;
            }
        });

    }

    // method when a link (text view) in xml is clicked
    public void link_action(View view){
       // webView = (WebView) findViewById(R.id.web_widget);  // PROBS DELETE THIS

        //TextView tv= (TextView) findViewById(R.id.text_view);

        // switch: depending what button you clicked, you get a different URL text
        switch(view.getId()) {
            case R.id.academic_year:
                urlText = getString(R.string.url_calendar);         // does this load the URL?
                //startActivity(new Intent(MainActivity.this, COVID.class));
            case R.id.the_921:
                urlText = getString(R.string.url_921);
               // startActivity(new Intent(MainActivity.this, Schedules.class));
            case R.id.cis_sandbox:
                urlText = getString(R.string.url_cis);
               // startActivity(new Intent(MainActivity.this, News.class));
            case R.id.learning_center:
                urlText = getString(R.string.url_learning);
                //startActivity(new Intent(MainActivity.this, Misc.class));
            case R.id.facilities:
                urlText = getString(R.string.url_dana);
                //startActivity(new Intent(MainActivity.this, Misc.class));
        }

        setContentView(R.layout.schedule_two);
        webView.loadUrl(urlText);   // IMPORTANT: OPENS URL UP IN WEBVIEW WIDGET
    }

    //the back key navigates back to the previous web page - SHOULD I CHANGE THIS? TEST HOW IT WORKS
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK) && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
