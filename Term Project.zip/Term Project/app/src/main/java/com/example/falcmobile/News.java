package com.example.falcmobile;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class News extends AppCompatActivity implements AdapterView.OnItemClickListener{

    private ListView listview, listview2;
    private String url;
    private WebView webView;
    private ArrayAdapter<String> adapt = null;
    private ArrayAdapter<String> adapt2 = null;
    public final static String MESSAGE_KEY ="com.example.falcmobile.message_key";
    private NotificationManager NotificationManager;
    private NotificationCompat.Builder builder = null;
    private int SIMPLE_NOTFICATION_ID = 25;
    private String CHANNEL_ID = "11";

    String[] vanguardItems = new String[]{
            "Spotlight: BSIG",
            "The Impact of the Blockage of the Suez Canal",
            "Netflix Review: Ginny & Georgia",
            "How to Become Anti-Racist",
    };

    String[] vanguardItems2 = new String[]{
            "The GameStop Frenzy",
            "Tour of Rome, Italy",
            "Capital Riots",
            "2020 Election in Review",
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.vanguard);

        // LIST 1: 2021 ARTICLES
        listview = (ListView) findViewById(R.id.list_vanguard_2021);
        listview.setOnItemClickListener(this);
        adapt = new ArrayAdapter<String>(this, R.layout.item, vanguardItems);
        listview.setAdapter(adapt);

        // LIST 2: 2020 ARTICLES
        listview2 = (ListView) findViewById(R.id.list_vanguard_2020);
        listview2.setOnItemClickListener(this);
        adapt2 = new ArrayAdapter<String>(this, R.layout.item, vanguardItems2);
        listview2.setAdapter(adapt2);

        // NOTIFICATIONS
        NotificationManager = (NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE);
        createNotificationChannel();

        // Create an explicit intent for an Activity
        Intent intent = new Intent(this, News.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK| Intent.FLAG_ACTIVITY_CLEAR_TASK);

        //the pending intent will outlive this app
       PendingIntent pendingIntent = PendingIntent.getActivity(this, 9, intent,0 );

        builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Android Notification")
                .setContentText("Vanguard Article has been opened")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                // Set the intent that will fire when the user taps the notification
                .setContentIntent(pendingIntent)
                .setAutoCancel(true);

        ListView start = (ListView) findViewById(R.id.list_vanguard_2021);

        //notify
        start.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //notify() in response to button click.
                NotificationManager.notify(SIMPLE_NOTFICATION_ID, builder.build());
            }
        });

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("default", "Channel foobar",
                    NotificationManager.IMPORTANCE_DEFAULT);channel.setDescription("Channel description");
            channel.setLightColor(Color.GREEN);
            channel.enableVibration(false);
            NotificationManager.createNotificationChannel(channel);
        }

    }


    //
    public void onItemClick(AdapterView<?> parent, View v, int position, long id) {


        switch (parent.getId()) {
            case R.id.list_vanguard_2021:

                switch (position) {
                    case 0:
                        url = "https://www.bentley-vanguard.com/post/spotlight-the-bentley-sustainable-investment-group";
                        Intent intent= new Intent(this ,WebLookUp.class);
                        intent.putExtra(MESSAGE_KEY,url);
                        startActivity(intent);
                        break;
                    case 1:
                        url = "https://www.bentley-vanguard.com/post/the-blockage-of-ever-given-in-suez-canal-impacts-global-markets";
                        Intent intent2= new Intent(this ,WebLookUp.class);
                        intent2.putExtra(MESSAGE_KEY,url);
                        startActivity(intent2);
                        break;
                    case 2:
                        url = "https://www.bentley-vanguard.com/post/netflix-original-review-ginny-and-georgia";
                        Intent intent3= new Intent(this ,WebLookUp.class);
                        intent3.putExtra(MESSAGE_KEY,url);
                        startActivity(intent3);
                        break;
                    case 3:
                        url = "https://www.bentley-vanguard.com/post/i-am-working-to-become-anti-racist-here-s-how-you-can-too";
                        Intent intent4= new Intent(this ,WebLookUp.class);
                        intent4.putExtra(MESSAGE_KEY,url);
                        startActivity(intent4);
                        break;
                }

                break;

            case R.id.list_vanguard_2020:

                switch (position) {
                    case 0:
                        url = "https://www.bentley-vanguard.com/post/the-gamestop-frenzy";
                        Intent intent= new Intent(this ,WebLookUp.class);
                        intent.putExtra(MESSAGE_KEY,url);
                        startActivity(intent);
                        break;
                    case 1:
                        url = "https://www.bentley-vanguard.com/post/tour-of-rome-italy";
                        Intent intent2= new Intent(this ,WebLookUp.class);
                        intent2.putExtra(MESSAGE_KEY,url);
                        startActivity(intent2);
                        break;
                    case 2:
                        url = "https://www.bentley-vanguard.com/post/capitol-riots-are-breaking-point-in-a-tense-time-for-american-politics";
                        Intent intent3= new Intent(this ,WebLookUp.class);
                        intent3.putExtra(MESSAGE_KEY,url);
                        startActivity(intent3);
                        break;
                    case 3:
                        url = "https://www.bentley-vanguard.com/post/2020-election-in-review";
                        Intent intent4= new Intent(this ,WebLookUp.class);
                        intent4.putExtra(MESSAGE_KEY,url);
                        startActivity(intent4);
                        break;
                }
                break;
        }
    }

    private void createNotificationChannel() {
        // Create the NotificationChannel

        if (Build.VERSION.SDK_INT>= Build.VERSION_CODES.O) {

            CharSequence name = "name of some.";
            String description = "string descr of something";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;

            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);

        }
    }
}
