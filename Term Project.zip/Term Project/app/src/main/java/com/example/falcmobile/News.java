package com.example.falcmobile;

public class News {
}
