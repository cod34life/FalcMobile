package com.example.falcmobile;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;

public class WebLookUp extends Activity {

private EditText enterURLbox;
private Button searchButton;
private WebView webView;
private Button backButton;

@Override
public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.web_browser); //create xml file

    backButton = (Button) findViewById(R.id.back);
    enterURLbox = (EditText) findViewById(R.id.enterURLbox);
    searchButton = (Button) findViewById(R.id.searchButton);
    webView = (WebView) findViewById(R.id.webView);
webView.getSettings().setJavaScriptEnabled(true);
    enterURLbox.setText("https://bentley.medicatconnect.com/home.aspx");
    webView.loadUrl("https://bentley.medicatconnect.com/home.aspx");

    webView.setWebViewClient(new WebViewClient(){
        @SuppressWarnings("deprecation")
        public boolean shouldOverrideUrlLoading(WebView view, String url){
            view.loadUrl(url);
            return true;
        }
    });

//makes button execute the search
    searchButton.setOnClickListener(new View.OnClickListener() {
        public void onClick(View view) {
            webView.loadUrl(enterURLbox.getText().toString());
        }
    });
//back button
    backButton.setOnClickListener(new View.OnClickListener() {
        public void onClick(View view) {
            if (webView.canGoBack()) {
                webView.goBack();
            }
        }
    });

//sets onkeylistener on EditText
    enterURLbox.setOnKeyListener(new View.OnKeyListener() {
        public boolean onKey(View view, int keyCode, KeyEvent event) {
            if (keyCode == KeyEvent.KEYCODE_ENTER) {
                webView.loadUrl(enterURLbox.getText().toString());
                return true;
            }
            return false;
        }
    });
}
//go back using back button
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK) && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }




}
