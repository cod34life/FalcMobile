package com.example.falcmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View.OnClickListener;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextClock;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements OnClickListener {

    private TextView home;
    private ImageButton cbtn;
    private ImageButton sbtn;
    private TextView covid;
    private TextView schedules;
    private ImageButton nbtn;
    private ImageButton mbtn;
    private TextView news;
    private TextView misc;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*locate all UI elements*/
        home = (TextView) findViewById(R.id.home);
        cbtn = (ImageButton) findViewById(R.id.cbtn);
        sbtn = (ImageButton) findViewById(R.id.sbtn);
        covid = (TextView) findViewById(R.id.covid);
        schedules = (TextView) findViewById(R.id.schedules);
        nbtn = (ImageButton) findViewById(R.id.nbtn);
        mbtn = (ImageButton) findViewById(R.id.mbtn);
        news = (TextView) findViewById(R.id.news);
        misc = (TextView) findViewById(R.id.misc);

        /*set onClickListener for all buttons*/
        cbtn.setOnClickListener(this);
        sbtn.setOnClickListener(this);
        nbtn.setOnClickListener(this);
        mbtn.setOnClickListener(this);

        public void onClick (View v) {
            switch(v.getId()) {
                case R.id.cbtn:
                    startActivity(new Intent(MainActivity.this, COVID.class));
                case R.id.sbtn:
                    startActivity(new Intent(MainActivity.this, Schedules.class));
                case R.id.nbtn:
                    startActivity(new Intent(MainActivity.this, News.class));
                case R.id.mbtn:
                    startActivity(new Intent(MainActivity.this, Misc.class));
            }
        }
    }
}