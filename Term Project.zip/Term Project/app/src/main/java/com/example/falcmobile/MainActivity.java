package com.example.falcmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View.OnClickListener;
import android.content.Intent;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextClock;
import android.widget.TextView;
import android.view.View;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends AppCompatActivity implements OnClickListener, TextToSpeech.OnInitListener {

    private TextView home;
    private ImageButton cbtn;
    private ImageButton sbtn;
    private TextView covid;
    private TextView schedules;
    private ImageButton nbtn;
    private ImageButton mbtn;
    private TextView news;
    private TextView maps;
    private TextToSpeech voice;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //locate all UI elements
        home = (TextView) findViewById(R.id.home);
        cbtn = (ImageButton) findViewById(R.id.cbtn);
        sbtn = (ImageButton) findViewById(R.id.sbtn);
        covid = (TextView) findViewById(R.id.covid);
        schedules = (TextView) findViewById(R.id.schedules);
        nbtn = (ImageButton) findViewById(R.id.nbtn);
        mbtn = (ImageButton) findViewById(R.id.mbtn);
        news = (TextView) findViewById(R.id.news);
        maps = (TextView) findViewById(R.id.maps);

        //set all listeners
        cbtn.setOnClickListener(this);
        sbtn.setOnClickListener(this);
        nbtn.setOnClickListener(this);
        mbtn.setOnClickListener(this);
        voice = new TextToSpeech(this, this);

    }

    @Override
    public void onClick (View v) {
        switch(v.getId()) {
            case R.id.cbtn:

                //rotate image
                Animation rcovid= (Animation)AnimationUtils.loadAnimation(getApplicationContext(), R.anim.rotate);
                cbtn.setAnimation(rcovid);
                
                //get text and read it out loud
                String optcovid = covid.getText().toString();
                speak("You have chosen the option " + optcovid);
                //start new activity
                startActivity(new Intent(MainActivity.this, COVID.class));
                break;

            case R.id.sbtn:

                Animation rschedules = (Animation)AnimationUtils.loadAnimation(getApplicationContext(), R.anim.rotate);
                cbtn.setAnimation(rschedules);

                String optschedules = schedules.getText().toString();
                speak("You have chosen the option " + optschedules);

                startActivity(new Intent(MainActivity.this, Schedules.class));
                break;

            case R.id.nbtn:

                Animation rnews = (Animation)AnimationUtils.loadAnimation(getApplicationContext(), R.anim.rotate);
                cbtn.setAnimation(rnews);

                String optnews= news.getText().toString();
                speak("You have chosen the option " + optnews);
                startActivity(new Intent(MainActivity.this, News.class));
                break;

            case R.id.mbtn:

                Animation rmaps= (Animation)AnimationUtils.loadAnimation(getApplicationContext(), R.anim.rotate);
                cbtn.setAnimation(rmaps);

                String optmaps = maps.getText().toString();
                speak("You have chosen the option " + optmaps);
                startActivity(new Intent(MainActivity.this, Misc.class));
                break;
        }
    }

    //set up TextToSpeech method
    public void speak (String output) {
        voice.speak(output, TextToSpeech.QUEUE_FLUSH, null, "Id 0");
    }

    //conditions for if voice works or not
    @Override
    public void onInit (int status){
        //if TextToSpeech enabled
        if (status == TextToSpeech.SUCCESS) {
            int result = voice.setLanguage(Locale.US);

            //if there's issues with the language chosen
            if (result == TextToSpeech.LANG_MISSING_DATA ||
                    result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Toast.makeText(this, "This language is not available or complete", Toast.LENGTH_LONG).show();
            }
        } else
            Toast.makeText(this, "An issue came up, so the device will remain silent for now", Toast.LENGTH_LONG).show();
    }
}