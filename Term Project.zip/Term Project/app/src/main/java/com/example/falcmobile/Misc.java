package com.example.falcmobile;
import android.content.res.Resources;
import androidx.fragment.app.FragmentActivity;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import android.view.ViewGroup;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class Misc extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private static final LatLng BENTLEY = new LatLng(42.3889167, -71.2208033);
    private static final float zoom = 14.0f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker at Bentley, set title and snippet, and move the camera
        mMap.addMarker(new MarkerOptions().position(new LatLng(42.383322509613805,-71.2247315972655)).title("Dana Center")
                .snippet("Stay Fit"));
        mMap.addMarker(new MarkerOptions().position(new LatLng(42.38597444664511,-71.22280791840066)).title("Student Center & 921 Cafe")
                .snippet("The Center of Student Life"));
        mMap.addMarker(new MarkerOptions().position(new LatLng(42.38787373152293,-71.22001412988365)).title("Einstein's bagels")
                .snippet("Best Breakfast in Bentley"));
        mMap.addMarker(new MarkerOptions().position(new LatLng(42.38477508648441,-71.22064712499022)).title("Bentley Arena")
                .snippet("Lets go Falcons!"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(BENTLEY, zoom));

        mMap.setOnMarkerClickListener(
                new GoogleMap.OnMarkerClickListener() {

                    public boolean onMarkerClick(Marker m) {
                        //get title and snippet to display on Toast
                        String title = m.getTitle();
                        String snip = m.getSnippet();
                        Toast.makeText(Misc.this, title + "\n" + snip, Toast.LENGTH_LONG).show();
                        return true;
                    }
                }
        );

    }
}
