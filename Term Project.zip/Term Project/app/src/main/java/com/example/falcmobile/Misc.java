package com.example.falcmobile;
import android.content.res.Resources;
import androidx.fragment.app.FragmentActivity;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TabHost;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class Misc extends FragmentActivity implements OnMapReadyCallback {
//MAP EATS

    TabHost tabs;
    //tab1
    private GoogleMap mMap;
    private static final LatLng BENTLEY = new LatLng(42.3889167, -71.2208033);
    private static final float zoom = 14.0f;

    //tab2
    private Button searchButton, backButton;
    private EditText enterURLbox;
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        tabs=(TabHost)findViewById(R.id.mainmenu);
        tabs.setup();
        TabHost.TabSpec spec;

        // Initialize a TabSpec for tab1 and add it to the TabHost
        spec=tabs.newTabSpec("tag1");	//create new tab specification
        spec.setContent(R.id.tab1);    //add tab view content
        spec.setIndicator("Map");    //put text on tab
        tabs.addTab(spec);             //put tab in TabHost container

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

// Initialize a TabSpec for tab1 and add it to the TabHost
        spec=tabs.newTabSpec("tag2");		//create new tab specification
        spec.setContent(R.id.tab2);			//add view tab content
        spec.setIndicator("Web");
        tabs.addTab(spec);					//put tab in TabHost container

        searchButton = (Button)findViewById(R.id.searchButton);
        backButton =(Button)findViewById(R.id.back);
        enterURLbox = (EditText)findViewById(R.id.enterURLbox);
        webView = (WebView)findViewById(R.id.web);
        //intercept URL loading and load in widget
        webView.setWebViewClient(new WebViewClient(){

            public boolean shouldOverrideUrlLoading(WebView view, String url){
                view.loadUrl(url);
                return true;
            }
        });
        //set listeners for web tab

        webView.setWebViewClient(new WebViewClient(){
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url){
                view.loadUrl(url);
                return true;
            }
        });

//makes button execute the search
        searchButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                webView.loadUrl(enterURLbox.getText().toString());
            }
        });
//back button
        backButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (webView.canGoBack()) {
                    webView.goBack();
                }
            }
        });

//sets onkeylistener on EditText
        enterURLbox.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View view, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER) {
                    webView.loadUrl(enterURLbox.getText().toString());
                    return true;
                }
                return false;
            }
        });

    }

    //google maps stuff for tab0
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(BENTLEY, zoom));

        // Add a marker at Bentley, set title and snippet, and move the camera
        mMap.addMarker(new MarkerOptions().position(new LatLng(42.383322509613805,-71.2247315972655)).title("Currito")
                .snippet("Stay Fit with Currito"));
        mMap.addMarker(new MarkerOptions().position(new LatLng(42.38597444664511,-71.22280791840066)).title("Harry's Pub")
                .snippet("Late Night Pub!"));
        mMap.addMarker(new MarkerOptions().position(new LatLng(42.38787373152293,-71.22001412988365)).title("Einstein's Bagels")
                .snippet("Best Breakfast in Bentley"));
        mMap.addMarker(new MarkerOptions().position(new LatLng(42.388694117486025,-71.22004975530423)).title("Lower Cafe")
                .snippet("Quality Food in Upper Campus!"));

        mMap.setOnMarkerClickListener(
                new GoogleMap.OnMarkerClickListener() {
                    public boolean onMarkerClick(Marker m) {
                        View v = null;
                        int aa = R.id.map;
                        String title = m.getTitle();
                        String snip = m.getSnippet();
                        Toast.makeText(getApplicationContext(), title + "\n" + snip, Toast.LENGTH_LONG).show();

                        if (m.getTitle().equals("Einstein's Bagels")) {
                            webView.loadUrl("https://locations.einsteinbros.com/us/ma/waltham/175-forest-st");
                            enterURLbox.setText("https://locations.einsteinbros.com/us/ma/waltham/175-forest-st");
                            tabs.setCurrentTab(1);
                        }
                        if (m.getTitle().equals("Harry's Pub")) {
                            webView.loadUrl("https://bentley.sodexomyway.com/dining-near-me/Harrys");
                            enterURLbox.setText("https://bentley.sodexomyway.com/dining-near-me/Harrys");
                            tabs.setCurrentTab(1);
                        }
                        if (m.getTitle().equals("Currito")) {
                            webView.loadUrl("https://bentley.sodexomyway.com/dining-near-me/currito");
                            enterURLbox.setText("https://bentley.sodexomyway.com/dining-near-me/currito");
                            tabs.setCurrentTab(1);
                        }
                        if (m.getTitle().equals("Lower Cafe")) {
                            webView.loadUrl("https://bentley.sodexomyway.com/dining-near-me/lower-cafe");
                            enterURLbox.setText("https://bentley.sodexomyway.com/dining-near-me/lower-cafe");
                            tabs.setCurrentTab(1);
                        }
                        return true;
                    }
                }
        );

    }
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_S) {
            mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
            return (true);
        }
        else if (keyCode == KeyEvent.KEYCODE_N) {
            mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
            return (true);
        }
        return (super.onKeyDown(keyCode, event));
    }
}
