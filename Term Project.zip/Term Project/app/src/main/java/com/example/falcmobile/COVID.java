package com.example.falcmobile;

public class COVID {
}
