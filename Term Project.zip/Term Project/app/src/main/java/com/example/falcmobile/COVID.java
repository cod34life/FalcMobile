package com.example.falcmobile;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class COVID extends AppCompatActivity implements View.OnClickListener {
    private WebView mainscreen;
    private Button scheduleButton;
    private TextView title;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.covid_resources);

// UI elements
        mainscreen = (WebView) findViewById(R.id.coviddashboard);
        scheduleButton = (Button) findViewById(R.id.scheduleTestButton);
        title = (TextView) findViewById(R.id.covidResourcesTitle);
//onclick listener for the button
        scheduleButton.setOnClickListener(this);
        //loads covid dashboard on webview
        mainscreen.loadUrl("https://www.bentley.edu/backtobentley/dashboard");
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()) {
            case R.id.scheduleTestButton:
                Intent intent1 = new Intent(this, WebLookUp.class);
                startActivity(intent1);
                break;
        }
    }
}
